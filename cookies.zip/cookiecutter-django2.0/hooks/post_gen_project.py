#!/usr/bin/env python 

print("""
Congratulations! {{cookiecutter.project_name}} had been created!

Now, cd into the {{cookiecutter.project_slug}} folder.

Execute this command to set up Django's admin and user databases:

    **python manage.py migrate**

At this point, you can start creating apps.
""")
