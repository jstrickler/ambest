from django.shortcuts import render

# Create your views here.

# example:
# def home(request):
#     context = { 'message': 'Hello' }
#     return render(request, '{{ cookiecutter.app_slug }}/home.html', context)
