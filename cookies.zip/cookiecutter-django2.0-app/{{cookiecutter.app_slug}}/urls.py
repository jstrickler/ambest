"""
URL Configuration for {{cookiecutter.app_slug}}
"""
from django.conf.urls import url
from . import views   # import views from app

urlpatterns = [
    # add url patterns for the {{cookiecutter.app_slug}} app here

    # Example:
#    url(r'^$', views.home, name='home'),
]
